import { Component } from '@angular/core';
import { NgStyle } from '@angular/common';

@Component({
  selector: 'app-stopka',
  standalone: true,
  imports: [NgStyle],
  templateUrl: './stopka.component.html',
  styleUrl: './stopka.component.css'
})
export class StopkaComponent {
color:string = 'lightgreen';
zmien():void{
  if(this.color=='lightgreen'){
    this.color = 'darkgreen';
  }else{
    this.color='lightgreen';
  }
}
}
